﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using MedicineTracking.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace MedicineTracking.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MedicineController : ControllerBase
    {
        private static readonly string JsonFilePath = $"JSON\\{"medicine.json"}";

        private readonly ILogger<MedicineController> _logger;

        public MedicineController(ILogger<MedicineController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<Medicine> GetAll()
        {
            var folderDetails = Path.Combine(Directory.GetCurrentDirectory(), JsonFilePath);
            var JSON = System.IO.File.ReadAllText(folderDetails);
            return JsonConvert.DeserializeObject<List<Medicine>>(Uri.UnescapeDataString(JSON));
        }

        [HttpGet]
        public Medicine GetMedicine(string name)
        {
            var folderDetails = Path.Combine(Directory.GetCurrentDirectory(), JsonFilePath);
            var JSON = System.IO.File.ReadAllText(folderDetails);
            var descValues = JsonConvert.DeserializeObject<List<Medicine>>(Uri.UnescapeDataString(JSON));
            return descValues.Find(x => x.Name == name);
        }

        [HttpPost]
        public IActionResult Post(Medicine medicine)
        {
            string jsondata = JsonConvert.SerializeObject(medicine); 
            System.IO.File.WriteAllText($"JSON\\{"medicine.json"}", jsondata);
            return Ok();
        }
    }
}
